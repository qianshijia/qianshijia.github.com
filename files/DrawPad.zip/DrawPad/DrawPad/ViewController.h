//
//  ViewController.h
//  DrawPad
//
//  Created by Shijia Qian on 11/09/12.
//  Copyright (c) 2012 UTAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIActionSheetDelegate, UIAlertViewDelegate>

@property (nonatomic, strong) IBOutlet UIImageView *mainImage;
@property (nonatomic, strong) IBOutlet UIImageView *drawingImage;
@property (nonatomic, strong) IBOutlet UIButton *colorPickBtn;
@property (nonatomic, strong) IBOutlet UIButton *brushPickBtn;
@property (nonatomic, strong) IBOutlet UIButton *eraserBtn;
@property (nonatomic, strong) IBOutlet UIButton *saveBtn;

-(IBAction)colorPickBtnPressed;
-(IBAction)brushPickBtnPressed;
-(IBAction)eraserPressed;
-(IBAction)saveBtnPressed;
-(IBAction)clearBtnPressed;
@end
