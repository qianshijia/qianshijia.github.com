//
//  ViewController.m
//  DrawPad
//
//  Created by Shijia Qian on 11/09/12.
//  Copyright (c) 2012 UTAS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    float red;
    float green;
    float blue;
    float brush;
    float opacity;
    BOOL fingerMoved;
    CGPoint lastPoint;
}
    
@property (nonatomic, strong) NSMutableDictionary *popoverDictionary;
@property (nonatomic, strong) UIView *viewThatPoped;

@end

@implementation ViewController

@synthesize mainImage = _mainImage;
@synthesize drawingImage = _drawingImage;
@synthesize colorPickBtn = _colorPickBtn;
@synthesize popoverDictionary = _popoverDictionary;
@synthesize viewThatPoped = _viewThatPoped;
@synthesize brushPickBtn = _brushPickBtn;
@synthesize eraserBtn = _eraserBtn;
@synthesize saveBtn = _saveBtn;

- (void)viewDidLoad
{
    _popoverDictionary = [[NSMutableDictionary alloc] init];
    
    red = 0.0 / 255.0;
    green = 0.0 / 255.0;
    blue = 0.0 / 255.0;
    brush = 5.0;
    opacity = 1.0;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)colorPickBtnPressed
{
    //如果已经有弹出菜单则把菜单remove掉
    if(self.viewThatPoped)
    {
        [self.viewThatPoped removeFromSuperview];
        self.viewThatPoped = nil;
        return;
    }
    //判断之前是否已经建立该菜单，如果建立了则直接从字典里获得这个菜单并把它添加到当前的View
    if([_popoverDictionary objectForKey:@"colors"])
    {
        UIView *popView = (UIView *)[_popoverDictionary objectForKey:@"colors"];
        popView.frame = CGRectMake(_colorPickBtn.frame.origin.x, _colorPickBtn.frame.origin.y - popView.frame.size.height, popView.frame.size.width, popView.frame.size.height);
        self.viewThatPoped = popView;
        [self.view addSubview:popView];
    }
    //否则就建立菜单
    else 
    {
        NSMutableArray *btnArray = [[NSMutableArray alloc] init];
        
        for(int i = 0; i < 7; i++)
        {
            UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
            b.frame = CGRectMake(0, 0, 45, 45);
            b.tag = i;
            [b setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"color%d.png", i+1]] forState:UIControlStateNormal];
            [b addTarget:self action:@selector(colorPressed:) forControlEvents:UIControlEventTouchUpInside];
            [btnArray addObject:b];
        }
        UIView *popView = [self popoverViewWithButtons:btnArray key:@"colors"];
        popView.frame = CGRectMake(_colorPickBtn.frame.origin.x, _colorPickBtn.frame.origin.y - popView.frame.size.height, popView.frame.size.width, popView.frame.size.height);
        self.viewThatPoped = popView;
        [self.view addSubview:popView];
    }
}

- (IBAction)brushPickBtnPressed
{
    if(self.viewThatPoped)
    {
        [self.viewThatPoped removeFromSuperview];
        self.viewThatPoped = nil;
        return;
    }
    if([_popoverDictionary objectForKey:@"brush"])
    {
        UIView *popView = (UIView *)[_popoverDictionary objectForKey:@"brush"];
        popView.frame = CGRectMake(_brushPickBtn.frame.origin.x, _brushPickBtn.frame.origin.y - popView.frame.size.height, popView.frame.size.width, popView.frame.size.height);
        self.viewThatPoped = popView;
        [self.view addSubview:popView];
    }
    else 
    {
        NSMutableArray *btnArray = [[NSMutableArray alloc] init];
        
        for(int i = 0; i < 4; i++)
        {
            UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
            b.frame = CGRectMake(0, 0, 45, 45);
            b.tag = i;
            [b setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%dpx.png", (i+1)*5]] forState:UIControlStateNormal];
            [b addTarget:self action:@selector(brushPressed:) forControlEvents:UIControlEventTouchUpInside];
            [btnArray addObject:b];
        }
        UIView *popView = [self popoverViewWithButtons:btnArray key:@"brush"];
        popView.frame = CGRectMake(_brushPickBtn.frame.origin.x, _brushPickBtn.frame.origin.y - popView.frame.size.height, popView.frame.size.width, popView.frame.size.height);
        self.viewThatPoped = popView;
        [self.view addSubview:popView];
    }
}

- (IBAction)clearBtnPressed
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Are you sure to clear all the drawings?" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    [alert show];
}

//方法接受两个参数，一个是按钮的数组，包含着所有的按钮，一个是key值，用来查找和保存字典里面的View
- (UIView *)popoverViewWithButtons:(NSArray *)buttons key:(NSString *)key
{
    //用key来判断是否已经建立了popoverView，如果已经建立过了，那就直接返回字典里保存的值，否则新建一个
    if([_popoverDictionary objectForKey:key])
    {
        return [_popoverDictionary objectForKey:key];
    }
    else 
    {
        if(buttons.count == 0)
        {
            NSLog(@"%@", @"There is no buttons in the array!");
            return nil;
        }
    
        CGFloat rowSpace = 4.0; 
        CGFloat viewWidth = ((UIButton *)[buttons objectAtIndex:0]).frame.size.width;
        CGFloat viewHeight = (((UIButton *)[buttons objectAtIndex:0]).frame.size.height + rowSpace) * buttons.count;
        UIView* popoverView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    
        int index = 0;
        for(UIButton *btn in buttons)
        {
            //把按钮add到View里，注意每个按钮的起始y坐标
            btn.frame = CGRectMake(0, (btn.frame.size.height + rowSpace) * index, btn.frame.size.width, btn.frame.size.width);
            [popoverView addSubview:btn];
            index++;
        }
        [_popoverDictionary setValue:popoverView forKey:key];
        return popoverView;
    }
    
}

- (void)colorPressed:(id)sender
{
    
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag) 
    {
        case 0:
            red = 255.0 / 255.0;
            green = 0.0 / 255.0;
            blue = 0.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 1:
            red = 0.0 / 255.0;
            green = 255.0 / 255.0;
            blue = 0.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 2:
            red = 0.0 / 255.0;
            green = 0.0 / 255.0;
            blue = 255.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 3:
            red = 255.0 / 255.0;
            green = 0.0 / 255.0;
            blue = 255.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 4:
            red = 255.0 / 255.0;
            green = 255.0 / 255.0;
            blue = 0.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 5:
            red = 0.0 / 255.0;
            green = 255.0 / 255.0;
            blue = 255.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 6:
            red = 0.0 / 255.0;
            green = 0.0 / 255.0;
            blue = 0.0 / 255.0;
            [self.colorPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
    }
    [self.eraserBtn setBackgroundImage:[UIImage imageNamed:@"eraser.png"] forState:UIControlStateNormal];
    [self.viewThatPoped removeFromSuperview];
    self.viewThatPoped = nil;
}

- (void)brushPressed:(id)sender
{
    
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag) 
    {
        case 0:
            brush = 5.0;
            [self.brushPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
            break;
        case 1:
            brush = 10.0;
            [self.brushPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
        case 2:
            brush = 15.0;
            [self.brushPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
        case 3:
            brush = 20.0;
            [self.brushPickBtn setBackgroundImage:[btn backgroundImageForState:UIControlStateNormal]  forState:UIControlStateNormal];
    }
    [self.viewThatPoped removeFromSuperview];
    self.viewThatPoped = nil;
}

- (IBAction)saveBtnPressed
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@""
                                                             delegate:self
                                                    cancelButtonTitle:@"Cancel"
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:@"Save to Camera Roll", nil];
    [actionSheet showInView:self.view];
}

-(IBAction)eraserPressed
{
    red = 255.0 / 255.0;
    green = 255.0 / 255.0;
    blue = 255.0 / 255.0;
    [self.eraserBtn setBackgroundImage:[UIImage imageNamed:@"eraserpressed.png"] forState:UIControlStateNormal];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        UIGraphicsBeginImageContextWithOptions(_mainImage.bounds.size, NO,0.0);
        [_mainImage.image drawInRect:CGRectMake(0, 0, _mainImage.frame.size.width, _mainImage.frame.size.height)];
        UIImage *SaveImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        UIImageWriteToSavedPhotosAlbum(SaveImage, self,@selector(image:didFinishSavingWithError:contextInfo:), nil);
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        self.mainImage.image = nil;
    }
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error != NULL)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Image could not be saved.Please try again"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Close", nil];
        [alert show];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Image was successfully saved in photoalbum!"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Close", nil];
        [alert show];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    fingerMoved = NO;
    UITouch *touch = [touches anyObject];
    lastPoint = [touch locationInView:self.view];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(self.viewThatPoped)
    {
        return;
    }
    fingerMoved = YES;
    UITouch *touch = [touches anyObject];
    CGPoint currentPoint = [touch locationInView:self.view];
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [self.drawingImage.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), currentPoint.x, currentPoint.y);
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush);
    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, 1.0);
    CGContextSetBlendMode(UIGraphicsGetCurrentContext(),kCGBlendModeNormal);
    
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    self.drawingImage.image = UIGraphicsGetImageFromCurrentImageContext();
    [self.drawingImage setAlpha:opacity];
    UIGraphicsEndImageContext();
    
    lastPoint = currentPoint;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(self.viewThatPoped)
    {
        [self.viewThatPoped removeFromSuperview];
        self.viewThatPoped = nil;
        return;
    }
    if(!fingerMoved) {
        UIGraphicsBeginImageContext(self.view.frame.size);
        [self.drawingImage.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
        CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush);
        CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, opacity);
        CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
        CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
        CGContextStrokePath(UIGraphicsGetCurrentContext());
        CGContextFlush(UIGraphicsGetCurrentContext());
        self.drawingImage.image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    
    UIGraphicsBeginImageContext(self.mainImage.frame.size);
    [self.mainImage.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) blendMode:kCGBlendModeNormal alpha:1.0];
    [self.drawingImage.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) blendMode:kCGBlendModeNormal alpha:opacity];
    self.mainImage.image = UIGraphicsGetImageFromCurrentImageContext();
    self.drawingImage.image = nil;
    UIGraphicsEndImageContext();
}
@end
